<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
?>

<h1>Нове завдання</h1>

<?php $form = ActiveForm::begin(); ?>

<?= $form->field($model, 'title') ?>
<?= $form->field($model, 'description')->textarea() ?>

<?= Html::submitButton('Зберегти', ['class' => 'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>
