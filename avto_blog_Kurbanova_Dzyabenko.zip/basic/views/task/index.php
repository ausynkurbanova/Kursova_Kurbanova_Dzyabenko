<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
?>

<h1>Список завдань</h1>

<?= Html::a('Додати завдання', ['create'], ['class' => 'btn btn-success']) ?>

<ul>
<?php foreach ($tasks as $task): ?>
    <li>
        <strong><?= Html::encode($task->title) ?></strong><br>
        <?= Html::encode($task->description) ?>
    </li>
<?php endforeach; ?>
</ul>
