<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $model app\models\Comment */
/* @var $parent app\models\Comment|null */

$this->title = isset($parent) ? 'Відповісти на коментар' : 'Додати коментар';
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php $form = ActiveForm::begin(); ?>
<?= $form->field($model,'author') ?>
<?= $form->field($model,'content')->textarea(['rows'=>4]) ?>
<div><br>
    <?= Html::submitButton('Зберегти',['class'=>'btn btn-success']) ?>
</div>
<?php ActiveForm::end(); ?>
