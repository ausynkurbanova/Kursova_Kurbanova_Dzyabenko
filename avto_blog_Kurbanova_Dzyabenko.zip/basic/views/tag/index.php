<?php
use yii\helpers\Html;

/* @var $tags app\models\Tag[] */
$this->title = 'Теги';
?>

<h1><?= Html::encode($this->title) ?></h1>
<p><?= Html::a('Додати тег',['create'],['class'=>'btn btn-success']) ?></p>

<table class="table table-bordered">
<tr><th>ID</th><th>Назва</th><th>Дії</th></tr>
<?php foreach($tags as $tag): ?>
<tr>
    <td><?= $tag->id ?></td>
    <td><?= Html::encode($tag->name) ?></td>
    <td>
        <?= Html::a('Редагувати',['update','id'=>$tag->id],['class'=>'btn btn-primary btn-sm']) ?>
        <?= Html::a('Видалити',['delete','id'=>$tag->id],['class'=>'btn btn-danger btn-sm','data'=>['confirm'=>'Видалити?','method'=>'post']]) ?>
    </td>
</tr>
<?php endforeach; ?>
</table>
