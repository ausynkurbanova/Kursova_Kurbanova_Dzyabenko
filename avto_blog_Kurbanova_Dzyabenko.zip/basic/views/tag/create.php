<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $model app\models\Tag */

$this->title = 'Додати тег';
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php $form = ActiveForm::begin(); ?>
<?= $form->field($model,'name') ?>
<div><br>
    <?= Html::submitButton('Зберегти',['class'=>'btn btn-success']) ?>
</div>
<?php ActiveForm::end(); ?>
