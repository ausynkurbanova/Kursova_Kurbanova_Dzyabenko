<?php
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $articles app\models\Article[] */

$this->title = 'Блог про автомобілі';
?>
<h1><?= Html::encode($this->title) ?></h1>

<?php foreach ($articles as $article): ?>
    <div style="border-bottom:1px solid #ccc; padding:10px;">
        <h2><?= Html::a(Html::encode($article->title), ['article/view', 'id'=>$article->id]) ?></h2>
        <p>Категорія: <?= Html::encode($article->category->title) ?></p>
        <p>Опубліковано: <?= Yii::$app->formatter->asDatetime($article->created_at) ?></p>
        <p><?= nl2br(Html::encode(mb_substr($article->content,0,200))) ?>...</p>
    </div>
<?php endforeach; ?>
