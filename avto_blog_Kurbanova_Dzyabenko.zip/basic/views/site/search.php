<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Пошук статей';
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php $form = ActiveForm::begin(['method' => 'get']); ?>
    <?= $form->field($model, 'query')->textInput(['placeholder' => 'Пошук по статтям...']) ?>
    <?= $form->field($model, 'category_id')->dropDownList(
        \yii\helpers\ArrayHelper::map($categories, 'id', 'name'),
        ['prompt' => 'Всі категорії']
    ) ?>
    <div class="form-group">
        <?= Html::submitButton('Шукати', ['class' => 'btn btn-primary']) ?>
    </div>
<?php ActiveForm::end(); ?>

<h2>Результати:</h2>
<?php if ($articles): ?>
    <ul>
        <?php foreach ($articles as $article): ?>
            <li>
                <?= Html::a(Html::encode($article->title), ['article/view', 'id' => $article->id]) ?>
                (Категорія: <?= Html::encode($article->category->name) ?>)
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>Нічого не знайдено.</p>
<?php endif; ?>
