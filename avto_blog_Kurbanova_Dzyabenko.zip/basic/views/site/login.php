<?php

use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Логін';
?>
<h1><?= Html::encode($this->title) ?></h1>

<div class="row justify-content-center">
    <div class="col-md-4">
        <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>

        <?= $form->field($model, 'username')->textInput(['autofocus' => true]) ?>
        <?= $form->field($model, 'password')->passwordInput() ?>
        <?= $form->field($model, 'rememberMe')->checkbox() ?>

        <div class="d-grid">
            <?= Html::submitButton('Увійти', ['class' => 'btn btn-primary']) ?>
        </div>

        <?php ActiveForm::end(); ?>
    </div>
</div>
