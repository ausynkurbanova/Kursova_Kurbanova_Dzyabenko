<?php
use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Реєстрація';
?>

<h1><?= Html::encode($this->title) ?></h1>

<div class="col-md-6">

    <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'username')->textInput(['autofocus' => true]) ?>

        <?= $form->field($model, 'email') ?>

        <?= $form->field($model, 'password')->passwordInput() ?>

        <div class="form-group mt-3">
            <?= Html::submitButton('Зареєструватися', ['class' => 'btn btn-success']) ?>
        </div>

    <?php ActiveForm::end(); ?>

</div>
