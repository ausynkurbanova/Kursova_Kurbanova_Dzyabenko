<?php

use yii\helpers\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;
use yii\widgets\Breadcrumbs;

$this->beginPage();
?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>

    <?php $this->head() ?>
    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php $this->beginBody() ?>

<?php
NavBar::begin([
    'brandLabel' => 'Мій Блог',
    'brandUrl' => Yii::$app->homeUrl,
    'options' => ['class' => 'navbar navbar-expand-lg navbar-light bg-light'],
]);

$menuItems = [
    ['label' => 'Головна', 'url' => ['/site/index']],
    ['label' => 'Статті', 'url' => ['/article/index']],
    ['label' => 'Категорії', 'url' => ['/category/index']],
    ['label' => 'Теги', 'url' => ['/tag/index']],
    ['label' => 'Пошук', 'url' => ['site/search']]
];

if (Yii::$app->user->isGuest) {
     $menuItems[] = ['label' => 'Реєстрація', 'url' => ['/site/register']];
    $menuItems[] = ['label' => 'Вхід', 'url' => ['/site/login']];
} else {
    $menuItems[] = '<li>'
        . Html::beginForm(['/site/logout'], 'post', ['class'=>'d-inline'])
        . Html::submitButton('Вихід (' . Yii::$app->user->identity->username . ')', ['class'=>'btn btn-link logout'])
        . Html::endForm()
        . '</li>';
}


echo Nav::widget([
    'options' => ['class' => 'navbar-nav ms-auto'],
    'items' => $menuItems,
]);

NavBar::end();
?>

<div class="container mt-4">
    <?= Breadcrumbs::widget([
        'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
    ]) ?>
    <?= $content ?>
</div>

<!-- jQuery & Bootstrap Bundle JS CDN -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/boot
