<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Article */
/* @var $categories app\models\Category[] */
/* @var $tags app\models\Tag[] */

$this->title = $model->isNewRecord ? 'Додати статтю' : 'Редагувати статтю';
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php $form = ActiveForm::begin(); ?>
<?= $form->field($model, 'title') ?>
<?= $form->field($model, 'content')->textarea(['rows'=>6]) ?>
<?= $form->field($model, 'category_id')->dropDownList(
    \yii\helpers\ArrayHelper::map($categories,'id','title'),
    ['prompt'=>'Оберіть категорію']
) ?>

<p>Теги:</p>
<?php foreach ($tags as $tag): ?>
    <?= Html::checkbox('tags[]', in_array($tag->id,$model->getTags()->select('id')->column()), ['value'=>$tag->id]) ?>
    <?= Html::encode($tag->name) ?><br>
<?php endforeach; ?>

<div><br>
    <?= Html::submitButton('Зберегти',['class'=>'btn btn-success']) ?>
</div>
<?php ActiveForm::end(); ?>
