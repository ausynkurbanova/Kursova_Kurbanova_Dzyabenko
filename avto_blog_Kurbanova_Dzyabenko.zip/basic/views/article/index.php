<?php
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $articles app\models\Article[] */
/* @var $search string|null */

$this->title = 'Статті';
?>

<h1><?= Html::encode($this->title) ?></h1>

<!-- Форма пошуку -->
<form method="get" class="mb-3">
    <input type="text" name="search" value="<?= Html::encode($search) ?>" placeholder="Пошук статей або категорій" class="form-control" style="max-width:300px; display:inline-block;">
    <button type="submit" class="btn btn-primary">Пошук</button>
</form>

<?php if (!Yii::$app->user->isGuest && Yii::$app->user->identity->role === 'admin'): ?>
    <p><?= Html::a('Додати статтю', ['create'], ['class'=>'btn btn-success']) ?></p>
<?php endif; ?>

<table class="table table-bordered">
<tr><th>ID</th><th>Назва</th><th>Категорія</th><th>Дії</th></tr>
<?php foreach ($articles as $article): ?>
<tr>
    <td><?= $article->id ?></td>
    <td><?= Html::a(Html::encode($article->title), ['view', 'id'=>$article->id]) ?></td>
    <td><?= Html::encode($article->category->title) ?></td>
    <td>
        <?php if (!Yii::$app->user->isGuest && Yii::$app->user->identity->role === 'admin'): ?>
            <?= Html::a('Редагувати',['update','id'=>$article->id],['class'=>'btn btn-primary btn-sm']) ?>
            <?= Html::a('Видалити',['delete','id'=>$article->id],['class'=>'btn btn-danger btn-sm','data'=>['confirm'=>'Видалити?','method'=>'post']]) ?>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</table>
