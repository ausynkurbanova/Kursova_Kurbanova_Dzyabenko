<?php
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $article app\models\Article */

$this->title = $article->title;
?>
<h1><?= Html::encode($article->title) ?></h1>
<p>Категорія: <?= Html::encode($article->category->title) ?> | Опубліковано: <?= Yii::$app->formatter->asDatetime($article->created_at) ?></p>
<p><?= nl2br(Html::encode($article->content)) ?></p>

<h3>Теги:</h3>
<p>
<?php foreach ($article->tags as $tag): ?>
    <?= Html::a(Html::encode($tag->name), ['tag/index']) ?> 
<?php endforeach; ?>
</p>

<h3>Коментарі:</h3>
<?php foreach ($article->comments as $comment): ?>
    <div style="border:1px solid #ddd; padding:5px; margin:5px;">
        <b><?= Html::encode($comment->author) ?>:</b>
        <p><?= nl2br(Html::encode($comment->content)) ?></p>
        <?= Html::a('Відповісти',['comment/reply','parent_id'=>$comment->id],['class'=>'btn btn-sm btn-secondary']) ?>
        <?php foreach ($comment->replies as $reply): ?>
            <div style="margin-left:20px; border-left:1px solid #ccc; padding-left:5px;">
                <b><?= Html::encode($reply->author) ?>:</b>
                <p><?= nl2br(Html::encode($reply->content)) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>

<p><?= Html::a('Додати коментар',['comment/create','article_id'=>$article->id],['class'=>'btn btn-primary']) ?></p>
