<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%article_tag}}`.
 */
class m251223_092902_create_article_tag_table extends Migration
{
    /**
     * {@inheritdoc}
     */
   public function safeUp()
    {
        $this->createTable('article_tag', [
            'article_id' => $this->integer()->notNull(),
            'tag_id' => $this->integer()->notNull(),
        ]);

        $this->addPrimaryKey(
            'pk-article_tag',
            'article_tag',
            ['article_id', 'tag_id']
        );

        // FK to article
        $this->addForeignKey(
            'fk-article_tag-article',
            'article_tag',
            'article_id',
            'article',
            'id',
            'CASCADE'
        );

        // FK to tag
        $this->addForeignKey(
            'fk-article_tag-tag',
            'article_tag',
            'tag_id',
            'tag',
            'id',
            'CASCADE'
        );
    }


    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%article_tag}}');
    }
}
