<?php

use yii\db\Migration;

class m251223_120636_create_admin_user extends Migration
{
    /**
     * {@inheritdoc}
     */
   public function safeUp()
    {
        $security = Yii::$app->getSecurity();

        $this->insert('user', [
            'username' => 'admin',
            'password_hash' => $security->generatePasswordHash('admin123'), // пароль admin123
            'auth_key' => $security->generateRandomString(),
            'access_token' => null,
        ]);
    }

    /**
     * {@inheritdoc}
     */
   public function safeDown()
    {
        $this->delete('user', ['username' => 'admin']);
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m251223_120636_create_admin_user cannot be reverted.\n";

        return false;
    }
    */
}
