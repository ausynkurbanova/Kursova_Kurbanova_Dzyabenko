<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%comment}}`.
 */
class m251223_092911_create_comment_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('comment', [
            'id' => $this->primaryKey(),
            'article_id' => $this->integer()->notNull(),
            'parent_id' => $this->integer(),
            'author' => $this->string(100)->notNull(),
            'content' => $this->text()->notNull(),
            'created_at' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'),
        ]);

        // Зв’язок на статтю
        $this->addForeignKey(
            'fk-comment-article',
            'comment',
            'article_id',
            'article',
            'id',
            'CASCADE'
        );

        // Деревоподібні коментарі
        $this->addForeignKey(
            'fk-comment-parent',
            'comment',
            'parent_id',
            'comment',
            'id',
            'CASCADE'
        );
    }
    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%comment}}');
    }
}
