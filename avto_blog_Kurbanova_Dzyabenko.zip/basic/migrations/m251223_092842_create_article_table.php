<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%article}}`.
 */
class m251223_092842_create_article_table extends Migration
{
    /**
     * {@inheritdoc}
     */
     public function safeUp()
    {
        $this->createTable('article', [
            'id' => $this->primaryKey(),
            'title' => $this->string(200)->notNull(),
            'content' => $this->text()->notNull(),
            'image' => $this->string(255),
            'created_at' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'),
            'category_id' => $this->integer()->notNull(),
        ]);
 $this->addForeignKey(
            'fk-article-category',
            'article',
            'category_id',
            'category',
            'id',
            'CASCADE'
        );
    }
    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey('fk-article-category', 'article');
        $this->dropTable('article');
    }
}
