<?php

use yii\db\Migration;

class m251226_115314_add_role_and_admin_user extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        // 1. Додаємо поле role
        $this->addColumn('user', 'role', $this->string()->defaultValue('user'));

        // 2. Створюємо адміністратора
        $password = 'admin123'; // пароль адміна
        $passwordHash = Yii::$app->security->generatePasswordHash($password);
        $authKey = Yii::$app->security->generateRandomString();

        $this->insert('user', [
            'username' => 'admin',
            'email' => 'admin@example.com',
            'password_hash' => $passwordHash,
            'auth_key' => $authKey,
            'role' => 'admin',
            'created_at' => time(),
            'updated_at' => time(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
     public function safeDown()
    {
        // Видаляємо адміна
        $this->delete('user', ['username' => 'admin']);
        $this->dropColumn('user', 'role');
    }


    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m251226_115314_add_role_and_admin_user cannot be reverted.\n";

        return false;
    }
    */
}
