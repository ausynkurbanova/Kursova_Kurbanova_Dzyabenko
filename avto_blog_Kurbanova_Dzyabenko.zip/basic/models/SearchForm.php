<?php
namespace app\models;

use yii\base\Model;
use app\models\Article;
use app\models\Category;

class SearchForm extends Model
{
    public $query;
    public $category_id;

    public function rules()
    {
        return [
            [['query'], 'string', 'max' => 255],
            [['category_id'], 'integer'],
        ];
    }

    /**
     * Пошук статей
     */
    public function search()
    {
        $query = Article::find()->orderBy(['created_at' => SORT_DESC]);

        if ($this->query) {
            $query->andWhere(['like', 'title', $this->query])
                  ->orWhere(['like', 'content', $this->query]);
        }

        if ($this->category_id) {
            $query->andWhere(['category_id' => $this->category_id]);
        }

        return $query->all();
    }
}
