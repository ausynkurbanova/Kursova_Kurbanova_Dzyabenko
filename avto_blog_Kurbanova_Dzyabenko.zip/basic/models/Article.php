<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class Article extends ActiveRecord
{
    public static function tableName()
    {
        return 'article';
    }

    public function rules()
    {
        return [
            [['title', 'content', 'category_id'], 'required'],
            [['content'], 'string'],
            [['category_id'], 'integer'],
            [['title'], 'string', 'max' => 200],
            [['image'], 'string', 'max' => 255],
        ];
    }

    // Зв’язок з Category
    public function getCategory()
    {
        return $this->hasOne(Category::class, ['id' => 'category_id']);
    }

    // Зв’язок з Tag через article_tag
    public function getTags()
    {
        return $this->hasMany(Tag::class, ['id' => 'tag_id'])
                    ->viaTable('article_tag', ['article_id' => 'id']);
    }

    // Зв’язок з Comment
    public function getComments()
    {
        return $this->hasMany(Comment::class, ['article_id' => 'id'])
                    ->where(['parent_id' => null])
                    ->orderBy(['created_at' => SORT_DESC]);
    }
}
