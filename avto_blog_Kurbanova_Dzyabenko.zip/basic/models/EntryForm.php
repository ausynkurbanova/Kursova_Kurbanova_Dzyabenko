<?php
namespace app\models;

use yii\base\Model;

class EntryForm extends Model
{
    public $name;
    public $email;

    public function rules()
    {
        return [
            // обидва поля обов'язкові
            [['name', 'email'], 'required', 'message' => 'Це поле не може бути порожнім'],
            // email повинен бути валідним
            ['email', 'email', 'message' => 'Введіть правильну адресу електронної пошти'],
            // обмеження на довжину імені
            ['name', 'string', 'min' => 2, 'max' => 50, 'tooShort' => 'Ім’я занадто коротке', 'tooLong' => 'Ім’я занадто довге'],
        ];
    }
}
