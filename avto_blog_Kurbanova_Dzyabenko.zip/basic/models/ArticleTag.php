<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class ArticleTag extends ActiveRecord
{
    public static function tableName()
    {
        return 'article_tag';
    }

    public function rules()
    {
        return [
            [['article_id', 'tag_id'], 'required'],
            [['article_id', 'tag_id'], 'integer'],
        ];
    }
}
