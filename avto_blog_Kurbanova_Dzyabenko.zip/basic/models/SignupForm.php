<?php

namespace app\models;

use yii\base\Model;
use app\models\User;

class SignupForm extends Model
{
    public $username;
    public $email;
    public $password;

    public function rules()
    {
        return [
            [['username', 'email', 'password'], 'required'],
            ['email', 'email'],
            ['username', 'string', 'min' => 3, 'max' => 50],
            ['password', 'string', 'min' => 6],
            ['email', 'unique', 'targetClass' => User::class, 'message' => 'Цей email вже зареєстрований.'],
            ['username', 'unique', 'targetClass' => User::class, 'message' => 'Це ім’я вже зайняте.'],
        ];
    }

    public function signup()
    {
        if (!$this->validate()) {
            return null;
        }

        $user = new User();
        $user->username = $this->username;
        $user->email = $this->email;
        $user->setPassword($this->password);
        $user->generateAuthKey();
        $user->role = 'user';


        return $user->save() ? $user : null;
    }
}
