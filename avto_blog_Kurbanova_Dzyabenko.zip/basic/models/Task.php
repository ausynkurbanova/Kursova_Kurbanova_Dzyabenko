<?php

namespace app\models;

use yii\db\ActiveRecord;

/**
 * Class Task
 * Модель для таблиці task
 *
 * @property int $id
 * @property string $title
 * @property string|null $description
 * @property int|null $created_at
 */
class Task extends ActiveRecord
{
    /**
     * Назва таблиці в БД
     */
    public static function tableName(): string
    {
        return 'task';
    }

    /**
     * Правила валідації
     */
    public function rules(): array
    {
        return [
            [['title'], 'required'],
            [['description'], 'string'],
            [['created_at'], 'integer'],
            [['title'], 'string', 'max' => 255],
        ];
    }

    /**
     * Мітка для атрибутів (для форм)
     */
    public function attributeLabels(): array
    {
        return [
            'id' => 'ID',
            'title' => 'Назва завдання',
            'description' => 'Опис завдання',
            'created_at' => 'Дата створення',
        ];
    }

    /**
     * Автоматично встановлює created_at при збереженні нового запису
     */
    public function beforeSave($insert): bool
    {
        if ($insert && empty($this->created_at)) {
            $this->created_at = time();
        }
        return parent::beforeSave($insert);
    }
}
