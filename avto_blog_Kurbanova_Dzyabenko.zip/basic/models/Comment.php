<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class Comment extends ActiveRecord
{
    public static function tableName()
    {
        return 'comment';
    }

    public function rules()
    {
        return [
            [['article_id', 'author', 'content'], 'required'],
            [['article_id', 'parent_id'], 'integer'],
            [['content'], 'string'],
            [['author'], 'string', 'max' => 100],
        ];
    }

    // Зв’язок з Article
    public function getArticle()
    {
        return $this->hasOne(Article::class, ['id' => 'article_id']);
    }

    // Батьківський коментар (для відповідей)
    public function getParent()
    {
        return $this->hasOne(Comment::class, ['id' => 'parent_id']);
    }

    // Всі дочірні коментарі
    public function getReplies()
    {
        return $this->hasMany(Comment::class, ['parent_id' => 'id']);
    }
}
