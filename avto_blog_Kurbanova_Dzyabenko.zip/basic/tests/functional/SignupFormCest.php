<?php
namespace tests\functional;

use FunctionalTester;

class SignupFormCest
{
    public function _before(FunctionalTester $I)
    {
        $I->amOnPage('/auth/signup');
    }

    public function signupNewUser(FunctionalTester $I)
    {
        $I->fillField('SignupForm[name]', 'Test User');
        $I->fillField('SignupForm[email]', 'newuser@example.com');
        $I->fillField('SignupForm[password]', '123456');
        $I->click('Register');
        $I->see('Login');
    }
}
