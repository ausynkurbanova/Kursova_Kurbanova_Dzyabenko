<?php
namespace tests\functional;

use FunctionalTester;

class LoginFormCest
{
    public function _before(FunctionalTester $I)
    {
        $I->amOnPage('/auth/login');
    }

    public function loginWithValidCredentials(FunctionalTester $I)
    {
        $I->fillField('LoginForm[email]', 'test@example.com');
        $I->fillField('LoginForm[password]', '123456');
        $I->click('Login');
        $I->see('Logout');
    }
}
