<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\AccessControl;
use app\models\Article;
use app\models\Category;
use app\models\Tag;

class ArticleController extends Controller
{
    public function behaviors()
{
    return [
        'access' => [
            'class' => AccessControl::class,
            'rules' => [
                // Адмінські дії
                [
                    'actions' => ['create','update','delete'],
                    'allow' => true,
                    'roles' => ['@'],
                    'matchCallback' => function($rule, $action) {
                        return Yii::$app->user->identity->role === 'admin';
                    }
                ],
                // Доступ для всіх авторизованих користувачів (index, view)
                [
                    'actions' => ['index','view'],
                    'allow' => true,
                    'roles' => ['@'],
                ],
            ],
        ],
    ];
}

    public function actionIndex($search = null)
{
    $query = Article::find()->joinWith('category');

    if ($search) {
        $query->andFilterWhere(['like', 'article.title', $search])
              ->orFilterWhere(['like', 'category.title', $search]);
    }

    $articles = $query->orderBy(['created_at' => SORT_DESC])->all();

    return $this->render('index', [
        'articles' => $articles,
        'search' => $search,
    ]);
}


    public function actionView($id)
    {
        $article = $this->findModel($id);
        return $this->render('view', ['article' => $article]);
    }

    public function actionCreate()
    {
        $model = new Article();
        $categories = Category::find()->all();
        $tags = Tag::find()->all();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            $model->unlinkAll('tags', true);
            if ($tagIds = Yii::$app->request->post('tags', [])) {
                foreach ($tagIds as $tagId) {
                    $tag = Tag::findOne($tagId);
                    if ($tag) $model->link('tags', $tag);
                }
            }
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
            'categories' => $categories,
            'tags' => $tags,
        ]);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $categories = Category::find()->all();
        $tags = Tag::find()->all();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            $model->unlinkAll('tags', true);
            if ($tagIds = Yii::$app->request->post('tags', [])) {
                foreach ($tagIds as $tagId) {
                    $tag = Tag::findOne($tagId);
                    if ($tag) $model->link('tags', $tag);
                }
            }
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
            'categories' => $categories,
            'tags' => $tags,
        ]);
    }

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        return $this->redirect(['index']);
    }

    protected function findModel($id): Article
    {
        if (($model = Article::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('Стаття не знайдена.');
    }
}
