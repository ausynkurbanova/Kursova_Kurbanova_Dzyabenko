<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\AccessControl;
use app\models\Category;

class CategoryController extends Controller
{
   public function behaviors()
{
    return [
        'access' => [
            'class' => AccessControl::class,
            'rules' => [
                // Адмінські дії
                [
                    'actions' => ['create','update','delete'],
                    'allow' => true,
                    'roles' => ['@'],
                    'matchCallback' => function($rule, $action) {
                        return Yii::$app->user->identity->role === 'admin';
                    }
                ],
                // Доступ для всіх авторизованих користувачів (index, view)
                [
                    'actions' => ['index','view'],
                    'allow' => true,
                    'roles' => ['@'],
                ],
            ],
        ],
    ];
}

    public function actionIndex($search = null)
{
    $query = Category::find();

    if ($search) {
        $query->andFilterWhere(['like', 'title', $search]);
    }

    $categories = $query->all();

    return $this->render('index', [
        'categories' => $categories,
        'search' => $search,
    ]);
}


    public function actionCreate()
    {
        $model = new Category();
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        }
        return $this->render('create', ['model'=>$model]);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        }
        return $this->render('update',['model'=>$model]);
    }

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        return $this->redirect(['index']);
    }

    protected function findModel($id): Category
    {
        if (($model = Category::findOne($id)) !== null) return $model;
        throw new NotFoundHttpException('Категорія не знайдена.');
    }
}

