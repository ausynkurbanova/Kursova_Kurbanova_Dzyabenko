<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\AccessControl;
use app\models\Comment;
use app\models\Article;

class CommentController extends Controller
{
    public function behaviors()
    {
        return [
            'access'=>[
                'class'=>AccessControl::class,
                'only'=>['create','reply','delete'],
                'rules'=>[
                    [
                        'actions'=>['create','reply','delete'],
                        'allow'=>true,
                        'roles'=>['@'],
                    ],
                ],
            ],
        ];
    }

    /**
     * Додавання коментаря до статті
     */
    public function actionCreate($article_id)
    {
        $model = new Comment();
        $model->article_id = $article_id;

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['article/view', 'id'=>$article_id]);
        }

        return $this->render('create',['model'=>$model]);
    }

    /**
     * Відповідь на коментар
     */
    public function actionReply($parent_id)
    {
        $parent = $this->findModel($parent_id);
        $model = new Comment();
        $model->article_id = $parent->article_id;
        $model->parent_id = $parent_id;

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['article/view', 'id'=>$parent->article_id]);
        }

        return $this->render('reply',['model'=>$model, 'parent'=>$parent]);
    }

    /**
     * Видалення коментаря
     */
    public function actionDelete($id)
    {
        $comment = $this->findModel($id);
        $article_id = $comment->article_id;
        $comment->delete();
        return $this->redirect(['article/view','id'=>$article_id]);
    }

    protected function findModel($id): Comment
    {
        if (($model = Comment::findOne($id))!==null) return $model;
        throw new NotFoundHttpException('Коментар не знайдено.');
    }
}
