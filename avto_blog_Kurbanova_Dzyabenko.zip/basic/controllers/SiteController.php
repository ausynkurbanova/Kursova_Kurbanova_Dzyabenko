<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\LoginForm;
use yii\filters\AccessControl;

class SiteController extends Controller
{
    /**
     * Поведінка доступу
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'], // тільки авторизовані
                    ],
                ],
            ],
        ];
    }

    /**
     * Головна сторінка блогу
     */
    public function actionIndex()
    {
        $articles = \app\models\Article::find()->orderBy(['created_at' => SORT_DESC])->all();
        return $this->render('index', ['articles' => $articles]);
    }

    /**
     * Логін
     */
    public function actionLogin()
{
    if (!Yii::$app->user->isGuest) {
        return $this->goHome();
    }

    $model = new \app\models\LoginForm();
    if ($model->load(Yii::$app->request->post()) && $model->login()) {
        return $this->goBack();
    }

    return $this->render('login', ['model' => $model]);
}
public function actionRegister()
{
    if (!Yii::$app->user->isGuest) {
        return $this->goHome();
    }

    $model = new \app\models\SignupForm();

    if ($model->load(Yii::$app->request->post()) && $model->signup()) {
        Yii::$app->session->setFlash('success', 'Реєстрація успішна! Можете увійти.');
        return $this->redirect(['login']);
    }

    return $this->render('register', [
        'model' => $model,
    ]);
}
public function actionSearch()
{
    $model = new \app\models\SearchForm();

    if ($model->load(Yii::$app->request->get())) {
        $articles = $model->search();
    } else {
        $articles = [];
    }

    $categories = \app\models\Category::find()->all();

    return $this->render('search', [
        'model' => $model,
        'articles' => $articles,
        'categories' => $categories,
    ]);
}

    /**
     * Логаут
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();
        return $this->goHome();
    }
}
