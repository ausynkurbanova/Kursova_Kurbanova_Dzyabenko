<?php
$params = require __DIR__ . '/params.php';
$db = require __DIR__ . '/db.php';

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@twbs'  => '@vendor/twbs/bootstrap', // alias для Bootstrap
    ],
    'components' => [
        'request' => [
            'cookieValidationKey' => 'your-secret-key',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'useFileTransport' => true,
        ],
        'log' => [
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'register' => 'site/register',
        'db' => $db,
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                '' => 'site/index',
                'login' => 'site/login',
                'logout' => 'site/logout',
                'articles' => 'article/index',
                'article/<id:\d+>' => 'article/view',
                'article/create' => 'article/create',
                'article/update/<id:\d+>' => 'article/update',
                'article/delete/<id:\d+>' => 'article/delete',
                'categories' => 'category/index',
                'category/create' => 'category/create',
                'category/update/<id:\d+>' => 'category/update',
                'category/delete/<id:\d+>' => 'category/delete',
                'tags' => 'tag/index',
                'tag/create' => 'tag/create',
                'tag/update/<id:\d+>' => 'tag/update',
                'tag/delete/<id:\d+>' => 'tag/delete',
                'comment/create/<article_id:\d+>' => 'comment/create',
                'comment/reply/<parent_id:\d+>' => 'comment/reply',
                'comment/delete/<id:\d+>' => 'comment/delete',
            ],
        ],
        'assetManager' => [
            'bundles' => [
                'yii\web\JqueryAsset' => [
                    'sourcePath' => '@bower/jquery/dist',
                    'js' => ['jquery.min.js'],
                ],
                'yii\bootstrap5\BootstrapAsset' => [
                    'sourcePath' => '@twbs/dist', // правильно вказуємо dist
                    'css' => ['css/bootstrap.min.css'],
                ],
                'yii\bootstrap5\BootstrapPluginAsset' => [
                    'sourcePath' => '@twbs/dist',
                    'js' => ['js/bootstrap.bundle.min.js'],
                ],
            ],
        ],
    ],
    'params' => $params,
];

return $config;

